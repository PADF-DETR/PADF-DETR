# Ultralytics YOLO 🚀, AGPL-3.0 license
"""Block modules."""

import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict

from .conv import Conv, DWConv, GhostConv, LightConv, RepConv
from .transformer import TransformerBlock

__all__ = ('DFL', 'HGBlock', 'HGStem', 'SPP', 'SPPF', 'C1', 'C2', 'C3', 'C2f', 'C3x', 'C3TR', 'C3Ghost',
           'GhostBottleneck', 'Bottleneck', 'BottleneckCSP', 'Proto', 'RepC3', 'ConvNormLayer', 'BasicBlock', 
           'BottleNeck', 'Blocks','PADR_Block','BASSA')


class DFL(nn.Module):
    """
    Integral module of Distribution Focal Loss (DFL).

    Proposed in Generalized Focal Loss https://ieeexplore.ieee.org/document/9792391
    """

    def __init__(self, c1=16):
        """Initialize a convolutional layer with a given number of input channels."""
        super().__init__()
        self.conv = nn.Conv2d(c1, 1, 1, bias=False).requires_grad_(False)
        x = torch.arange(c1, dtype=torch.float)
        self.conv.weight.data[:] = nn.Parameter(x.view(1, c1, 1, 1))
        self.c1 = c1

    def forward(self, x):
        """Applies a transformer layer on input tensor 'x' and returns a tensor."""
        b, c, a = x.shape  # batch, channels, anchors
        return self.conv(x.view(b, 4, self.c1, a).transpose(2, 1).softmax(1)).view(b, 4, a)
        # return self.conv(x.view(b, self.c1, 4, a).softmax(1)).view(b, 4, a)


class Proto(nn.Module):
    """YOLOv8 mask Proto module for segmentation models."""

    def __init__(self, c1, c_=256, c2=32):
        """
        Initializes the YOLOv8 mask Proto module with specified number of protos and masks.

        Input arguments are ch_in, number of protos, number of masks.
        """
        super().__init__()
        self.cv1 = Conv(c1, c_, k=3)
        self.upsample = nn.ConvTranspose2d(c_, c_, 2, 2, 0, bias=True)  # nn.Upsample(scale_factor=2, mode='nearest')
        self.cv2 = Conv(c_, c_, k=3)
        self.cv3 = Conv(c_, c2)

    def forward(self, x):
        """Performs a forward pass through layers using an upsampled input image."""
        return self.cv3(self.cv2(self.upsample(self.cv1(x))))


class HGStem(nn.Module):
    """
    StemBlock of PPHGNetV2 with 5 convolutions and one maxpool2d.

    https://github.com/PaddlePaddle/PaddleDetection/blob/develop/ppdet/modeling/backbones/hgnet_v2.py
    """

    def __init__(self, c1, cm, c2):
        """Initialize the SPP layer with input/output channels and specified kernel sizes for max pooling."""
        super().__init__()
        self.stem1 = Conv(c1, cm, 3, 2, act=nn.ReLU())
        self.stem2a = Conv(cm, cm // 2, 2, 1, 0, act=nn.ReLU())
        self.stem2b = Conv(cm // 2, cm, 2, 1, 0, act=nn.ReLU())
        self.stem3 = Conv(cm * 2, cm, 3, 2, act=nn.ReLU())
        self.stem4 = Conv(cm, c2, 1, 1, act=nn.ReLU())
        self.pool = nn.MaxPool2d(kernel_size=2, stride=1, padding=0, ceil_mode=True)

    def forward(self, x):
        """Forward pass of a PPHGNetV2 backbone layer."""
        x = self.stem1(x)
        x = F.pad(x, [0, 1, 0, 1])
        x2 = self.stem2a(x)
        x2 = F.pad(x2, [0, 1, 0, 1])
        x2 = self.stem2b(x2)
        x1 = self.pool(x)
        x = torch.cat([x1, x2], dim=1)
        x = self.stem3(x)
        x = self.stem4(x)
        return x


class HGBlock(nn.Module):
    """
    HG_Block of PPHGNetV2 with 2 convolutions and LightConv.

    https://github.com/PaddlePaddle/PaddleDetection/blob/develop/ppdet/modeling/backbones/hgnet_v2.py
    """

    def __init__(self, c1, cm, c2, k=3, n=6, lightconv=False, shortcut=False, act=nn.ReLU()):
        """Initializes a CSP Bottleneck with 1 convolution using specified input and output channels."""
        super().__init__()
        block = LightConv if lightconv else Conv
        self.m = nn.ModuleList(block(c1 if i == 0 else cm, cm, k=k, act=act) for i in range(n))
        self.sc = Conv(c1 + n * cm, c2 // 2, 1, 1, act=act)  # squeeze conv
        self.ec = Conv(c2 // 2, c2, 1, 1, act=act)  # excitation conv
        self.add = shortcut and c1 == c2

    def forward(self, x):
        """Forward pass of a PPHGNetV2 backbone layer."""
        y = [x]
        y.extend(m(y[-1]) for m in self.m)
        y = self.ec(self.sc(torch.cat(y, 1)))
        return y + x if self.add else y


class SPP(nn.Module):
    """Spatial Pyramid Pooling (SPP) layer https://arxiv.org/abs/1406.4729."""

    def __init__(self, c1, c2, k=(5, 9, 13)):
        """Initialize the SPP layer with input/output channels and pooling kernel sizes."""
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * (len(k) + 1), c2, 1, 1)
        self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])

    def forward(self, x):
        """Forward pass of the SPP layer, performing spatial pyramid pooling."""
        x = self.cv1(x)
        return self.cv2(torch.cat([x] + [m(x) for m in self.m], 1))


class SPPF(nn.Module):
    """Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher."""

    def __init__(self, c1, c2, k=5):
        """
        Initializes the SPPF layer with given input/output channels and kernel size.

        This module is equivalent to SPP(k=(5, 9, 13)).
        """
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        """Forward pass through Ghost Convolution block."""
        x = self.cv1(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        return self.cv2(torch.cat((x, y1, y2, self.m(y2)), 1))


class C1(nn.Module):
    """CSP Bottleneck with 1 convolution."""

    def __init__(self, c1, c2, n=1):
        """Initializes the CSP Bottleneck with configurations for 1 convolution with arguments ch_in, ch_out, number."""
        super().__init__()
        self.cv1 = Conv(c1, c2, 1, 1)
        self.m = nn.Sequential(*(Conv(c2, c2, 3) for _ in range(n)))

    def forward(self, x):
        """Applies cross-convolutions to input in the C3 module."""
        y = self.cv1(x)
        return self.m(y) + y


class C2(nn.Module):
    """CSP Bottleneck with 2 convolutions."""

    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        """Initializes the CSP Bottleneck with 2 convolutions module with arguments ch_in, ch_out, number, shortcut,
        groups, expansion.
        """
        super().__init__()
        self.c = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv(2 * self.c, c2, 1)  # optional act=FReLU(c2)
        # self.attention = ChannelAttention(2 * self.c)  # or SpatialAttention()
        self.m = nn.Sequential(*(Bottleneck(self.c, self.c, shortcut, g, k=((3, 3), (3, 3)), e=1.0) for _ in range(n)))

    def forward(self, x):
        """Forward pass through the CSP bottleneck with 2 convolutions."""
        a, b = self.cv1(x).chunk(2, 1)
        return self.cv2(torch.cat((self.m(a), b), 1))


class C2f(nn.Module):
    """Faster Implementation of CSP Bottleneck with 2 convolutions."""

    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        """Initialize CSP bottleneck layer with two convolutions with arguments ch_in, ch_out, number, shortcut, groups,
        expansion.
        """
        super().__init__()
        self.c = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.ModuleList(Bottleneck(self.c, self.c, shortcut, g, k=((3, 3), (3, 3)), e=1.0) for _ in range(n))

    def forward(self, x):
        """Forward pass through C2f layer."""
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))

    def forward_split(self, x):
        """Forward pass using split() instead of chunk()."""
        y = list(self.cv1(x).split((self.c, self.c), 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))


class C3(nn.Module):
    """CSP Bottleneck with 3 convolutions."""

    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        """Initialize the CSP Bottleneck with given channels, number, shortcut, groups, and expansion values."""
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, k=((1, 1), (3, 3)), e=1.0) for _ in range(n)))

    def forward(self, x):
        """Forward pass through the CSP bottleneck with 2 convolutions."""
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), 1))


class C3x(C3):
    """C3 module with cross-convolutions."""

    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        """Initialize C3TR instance and set default parameters."""
        super().__init__(c1, c2, n, shortcut, g, e)
        self.c_ = int(c2 * e)
        self.m = nn.Sequential(*(Bottleneck(self.c_, self.c_, shortcut, g, k=((1, 3), (3, 1)), e=1) for _ in range(n)))


class RepC3(nn.Module):
    """Rep C3."""

    def __init__(self, c1, c2, n=3, e=1.0):
        """Initialize CSP Bottleneck with a single convolution using input channels, output channels, and number."""
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.m = nn.Sequential(*[RepConv(c_, c_) for _ in range(n)])
        self.cv3 = Conv(c_, c2, 1, 1) if c_ != c2 else nn.Identity()

    def forward(self, x):
        """Forward pass of RT-DETR neck layer."""
        return self.cv3(self.m(self.cv1(x)) + self.cv2(x))


class C3TR(C3):
    """C3 module with TransformerBlock()."""

    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        """Initialize C3Ghost module with GhostBottleneck()."""
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = TransformerBlock(c_, c_, 4, n)


class C3Ghost(C3):
    """C3 module with GhostBottleneck()."""

    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        """Initialize 'SPP' module with various pooling sizes for spatial pyramid pooling."""
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(GhostBottleneck(c_, c_) for _ in range(n)))


class GhostBottleneck(nn.Module):
    """Ghost Bottleneck https://github.com/huawei-noah/ghostnet."""

    def __init__(self, c1, c2, k=3, s=1):
        """Initializes GhostBottleneck module with arguments ch_in, ch_out, kernel, stride."""
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(
            GhostConv(c1, c_, 1, 1),  # pw
            DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
            GhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False), Conv(c1, c2, 1, 1,
                                                                            act=False)) if s == 2 else nn.Identity()

    def forward(self, x):
        """Applies skip connection and concatenation to input tensor."""
        return self.conv(x) + self.shortcut(x)


class Bottleneck(nn.Module):
    """Standard bottleneck."""

    def __init__(self, c1, c2, shortcut=True, g=1, k=(3, 3), e=0.5):
        """Initializes a bottleneck module with given input/output channels, shortcut option, group, kernels, and
        expansion.
        """
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, k[0], 1)
        self.cv2 = Conv(c_, c2, k[1], 1, g=g)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        """'forward()' applies the YOLO FPN to input data."""
        return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))


class BottleneckCSP(nn.Module):
    """CSP Bottleneck https://github.com/WongKinYiu/CrossStagePartialNetworks."""

    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        """Initializes the CSP Bottleneck given arguments for ch_in, ch_out, number, shortcut, groups, expansion."""
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = nn.Conv2d(c1, c_, 1, 1, bias=False)
        self.cv3 = nn.Conv2d(c_, c_, 1, 1, bias=False)
        self.cv4 = Conv(2 * c_, c2, 1, 1)
        self.bn = nn.BatchNorm2d(2 * c_)  # applied to cat(cv2, cv3)
        self.act = nn.SiLU()
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        """Applies a CSP bottleneck with 3 convolutions."""
        y1 = self.cv3(self.m(self.cv1(x)))
        y2 = self.cv2(x)
        return self.cv4(self.act(self.bn(torch.cat((y1, y2), 1))))

################################### RT-DETR PResnet ###################################
def get_activation(act: str, inpace: bool=True):
    '''get activation
    '''
    act = act.lower()
    
    if act == 'silu':
        m = nn.SiLU()

    elif act == 'relu':
        m = nn.ReLU()

    elif act == 'leaky_relu':
        m = nn.LeakyReLU()

    elif act == 'silu':
        m = nn.SiLU()
    
    elif act == 'gelu':
        m = nn.GELU()
        
    elif act is None:
        m = nn.Identity()
    
    elif isinstance(act, nn.Module):
        m = act

    else:
        raise RuntimeError('')  

    if hasattr(m, 'inplace'):
        m.inplace = inpace
    
    return m 

class ConvNormLayer(nn.Module):
    def __init__(self, ch_in, ch_out, kernel_size, stride, padding=None, bias=False, act=None):
        super().__init__()
        self.conv = nn.Conv2d(
            ch_in, 
            ch_out, 
            kernel_size, 
            stride, 
            padding=(kernel_size-1)//2 if padding is None else padding, 
            bias=bias)
        self.norm = nn.BatchNorm2d(ch_out)
        self.act = nn.Identity() if act is None else get_activation(act) 

    def forward(self, x):
        return self.act(self.norm(self.conv(x)))
    
    def forward_fuse(self, x):
        """Perform transposed convolution of 2D data."""
        return self.act(self.conv(x))

class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, ch_in, ch_out, stride, shortcut, act='relu', variant='d'):
        super().__init__()

        self.shortcut = shortcut

        if not shortcut:
            if variant == 'd' and stride == 2:
                self.short = nn.Sequential(OrderedDict([
                    ('pool', nn.AvgPool2d(2, 2, 0, ceil_mode=True)),
                    ('conv', ConvNormLayer(ch_in, ch_out, 1, 1))
                ]))
            else:
                self.short = ConvNormLayer(ch_in, ch_out, 1, stride)

        self.branch2a = ConvNormLayer(ch_in, ch_out, 3, stride, act=act)
        self.branch2b = ConvNormLayer(ch_out, ch_out, 3, 1, act=None)
        self.act = nn.Identity() if act is None else get_activation(act) 


    def forward(self, x):
        out = self.branch2a(x)
        out = self.branch2b(out)
        if self.shortcut:
            short = x
        else:
            short = self.short(x)
        
        out = out + short
        out = self.act(out)

        return out


class BottleNeck(nn.Module):
    expansion = 4

    def __init__(self, ch_in, ch_out, stride, shortcut, act='relu', variant='d'):
        super().__init__()

        if variant == 'a':
            stride1, stride2 = stride, 1
        else:
            stride1, stride2 = 1, stride

        width = ch_out 

        self.branch2a = ConvNormLayer(ch_in, width, 1, stride1, act=act)
        self.branch2b = ConvNormLayer(width, width, 3, stride2, act=act)
        self.branch2c = ConvNormLayer(width, ch_out * self.expansion, 1, 1)

        self.shortcut = shortcut
        if not shortcut:
            if variant == 'd' and stride == 2:
                self.short = nn.Sequential(OrderedDict([
                    ('pool', nn.AvgPool2d(2, 2, 0, ceil_mode=True)),
                    ('conv', ConvNormLayer(ch_in, ch_out * self.expansion, 1, 1))
                ]))
            else:
                self.short = ConvNormLayer(ch_in, ch_out * self.expansion, 1, stride)

        self.act = nn.Identity() if act is None else get_activation(act) 

    def forward(self, x):
        out = self.branch2a(x)
        out = self.branch2b(out)
        out = self.branch2c(out)

        if self.shortcut:
            short = x
        else:
            short = self.short(x)

        out = out + short
        out = self.act(out)

        return out


class Blocks(nn.Module):
    def __init__(self, ch_in, ch_out, block, count, stage_num, act='relu', input_resolution=None, sr_ratio=None, kernel_size=None, kan_name=None, variant='d'):
        super().__init__()

        self.blocks = nn.ModuleList()
        for i in range(count):
            if input_resolution is not None and sr_ratio is not None:
                self.blocks.append(
                    block(
                        ch_in, 
                        ch_out,
                        stride=2 if i == 0 and stage_num != 2 else 1, 
                        shortcut=False if i == 0 else True,
                        variant=variant,
                        act=act,
                        input_resolution=input_resolution,
                        sr_ratio=sr_ratio)
                )
            elif kernel_size is not None:
                self.blocks.append(
                    block(
                        ch_in, 
                        ch_out,
                        stride=2 if i == 0 and stage_num != 2 else 1, 
                        shortcut=False if i == 0 else True,
                        variant=variant,
                        act=act,
                        kernel_size=kernel_size)
                )
            elif kan_name is not None:
                self.blocks.append(
                    block(
                        ch_in, 
                        ch_out,
                        stride=2 if i == 0 and stage_num != 2 else 1, 
                        shortcut=False if i == 0 else True,
                        variant=variant,
                        act=act,
                        kan_name=kan_name)
                )
            else:
                self.blocks.append(
                    block(
                        ch_in, 
                        ch_out,
                        stride=2 if i == 0 and stage_num != 2 else 1, 
                        shortcut=False if i == 0 else True,
                        variant=variant,
                        act=act)
                )
            if i == 0:
                ch_in = ch_out * block.expansion

    def forward(self, x):
        out = x
        for block in self.blocks:
            out = block(out)
        return out
    
    
    
    








    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
import torch
import torch.nn as nn
import torch.nn.functional as F


class StripPoseAttention(nn.Module):

    def __init__(self, channels, reduction=16):
        super().__init__()
        mid_ch = max(channels // reduction, 8)

        self.vertical_strip = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=(9, 1), padding=(4, 0),
                      groups=channels, bias=False),
            nn.BatchNorm2d(channels),
        )

        self.horizontal_strip = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=(1, 9), padding=(0, 4),
                      groups=channels, bias=False),
            nn.BatchNorm2d(channels),
        )

        self.pose_gate = nn.Sequential(
            nn.Conv2d(channels * 2, mid_ch, kernel_size=1, bias=False),
            nn.BatchNorm2d(mid_ch),
            nn.GELU(),
            nn.Conv2d(mid_ch, channels, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

        self.channel_gate = nn.Sequential(
            nn.Conv2d(channels * 2, mid_ch, kernel_size=1, bias=False),
            nn.GELU(),
            nn.Conv2d(mid_ch, channels, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        v_pose = self.vertical_strip(x)
        h_pose = self.horizontal_strip(x)

        pose_feat = torch.cat([v_pose, h_pose], dim=1)
        sp_weight = self.pose_gate(pose_feat)

        avg_desc = F.adaptive_avg_pool2d(x, 1)
        max_desc = F.adaptive_max_pool2d(x, 1)
        ch_desc = torch.cat([avg_desc, max_desc], dim=1)
        ch_weight = self.channel_gate(ch_desc)

        return x * sp_weight * ch_weight + x


class DualContextFusion(nn.Module):

    def __init__(self, channels, num_inputs):
        super().__init__()
        self.num_inputs = num_inputs

        self.context_encoders = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(channels * 2, max(channels // 8, 8),
                          kernel_size=1, bias=False),
                nn.BatchNorm2d(max(channels // 8, 8)),
                nn.GELU(),
                nn.Conv2d(max(channels // 8, 8), 1, kernel_size=1, bias=False),
            ) for _ in range(num_inputs)
        ])

        self.refine = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1,
                      groups=channels, bias=False),
            nn.Conv2d(channels, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.GELU(),
        )

    def forward(self, features):
        scores = []
        for feat, encoder in zip(features, self.context_encoders):
            avg_ctx = F.adaptive_avg_pool2d(feat, 1)
            max_ctx = F.adaptive_max_pool2d(feat, 1)
            ctx = torch.cat([avg_ctx, max_ctx], dim=1)
            scores.append(encoder(ctx))  # [B, 1, 1, 1]

        scores = torch.cat(scores, dim=1)  # [B, num_inputs, 1, 1]
        weights = F.softmax(scores, dim=1)

        fused = sum(
            feat * weights[:, i:i + 1] for i, feat in enumerate(features)
        )

        return self.refine(fused)


class PADR_Block(nn.Module):

    def __init__(self, ch_in, ch_out, block, count, stage_num, act='relu',
                 input_resolution=None, sr_ratio=None, kernel_size=None,
                 kan_name=None, variant='d'):
        super().__init__()

        self.blocks = nn.ModuleList()
        self.attentions = nn.ModuleList()

        current_ch_in = ch_in

        for i in range(count):
            kwargs = dict(
                stride=2 if i == 0 and stage_num != 2 else 1,
                shortcut=False if i == 0 else True,
                variant=variant,
                act=act
            )
            if input_resolution is not None and sr_ratio is not None:
                kwargs.update(input_resolution=input_resolution, sr_ratio=sr_ratio)
            elif kernel_size is not None:
                kwargs.update(kernel_size=kernel_size)
            elif kan_name is not None:
                kwargs.update(kan_name=kan_name)

            self.blocks.append(block(current_ch_in, ch_out, **kwargs))

            if i == 0:
                current_ch_in = ch_out * block.expansion

            out_ch = ch_out * block.expansion

            self.attentions.append(StripPoseAttention(out_ch))

        final_ch = ch_out * block.expansion
        self.has_ch_mismatch = (ch_in != final_ch)
        self.has_stride = (stage_num != 2)

        if self.has_ch_mismatch or self.has_stride:
            stride_val = 2 if self.has_stride else 1
            self.input_proj = nn.Sequential(
                nn.Conv2d(ch_in, final_ch, kernel_size=1,
                          stride=stride_val, bias=False),
                nn.BatchNorm2d(final_ch),
            )
        else:
            self.input_proj = nn.Identity()

        self.aggregation = DualContextFusion(final_ch, num_inputs=count + 1)

        self.action_context = nn.Sequential(
            nn.Conv2d(final_ch, final_ch, kernel_size=5, padding=2,
                      groups=final_ch, bias=False),
            nn.BatchNorm2d(final_ch),
            nn.GELU(),
            nn.Conv2d(final_ch, final_ch, kernel_size=1, bias=False),
            nn.BatchNorm2d(final_ch),
        )

    def forward(self, x):
        identity = self.input_proj(x)

        intermediates = [identity]
        out = x
        for blk, attn in zip(self.blocks, self.attentions):
            out = blk(out)
            out = attn(out)
            intermediates.append(out)

        fused = self.aggregation(intermediates)

        contextual = self.action_context(fused)

        return contextual + out
    
    
    
    
    
    












import torch
import torch.nn as nn
import torch.nn.functional as F


@torch.jit.script
def recurrent_selective_scan(u, dt, B_ssm, C_ssm, A, D_param):
    Bsz, L, Din = u.shape
    N = B_ssm.shape[-1]

    h = torch.zeros(Bsz, Din, N, device=u.device, dtype=u.dtype)
    ys = torch.empty(Bsz, L, Din, device=u.device, dtype=u.dtype)

    for t in range(L):
        dt_t = dt[:, t]                            # [Bsz, Din]
        u_t = u[:, t]                              # [Bsz, Din]
        B_t = B_ssm[:, t]                          # [Bsz, N]
        C_t = C_ssm[:, t]                          # [Bsz, N]

        # dA: [Bsz, Din, N] = A[None,None,:] * dt_t[:,:,None]
        dA = torch.exp(A.view(1, 1, N) * dt_t.unsqueeze(-1))
        # dBu: [Bsz, Din, N] = dt_t * u_t (广播到 Din) 乘 B_t
        dBu = (dt_t * u_t).unsqueeze(-1) * B_t.unsqueeze(1)

        h = h * dA + dBu                           # 
        y_t = (h * C_t.unsqueeze(1)).sum(dim=-1)   # [Bsz, Din]
        ys[:, t] = y_t + u_t * D_param.unsqueeze(0)

    return ys


class BASSA(nn.Module):

    def __init__(self, dim, d_state=8, d_conv=3, expand=1, dropout=0.0):
        super().__init__()
        self.dim = dim
        self.d_inner = int(expand * dim)
        self.d_state = d_state

        self.in_proj = nn.Conv2d(dim, self.d_inner, 1, bias=False)

        self.dw_conv = nn.Conv2d(
            self.d_inner, self.d_inner,
            kernel_size=d_conv, padding=d_conv // 2,
            groups=self.d_inner, bias=True,
        )
        self.act = nn.SiLU(inplace=False)

        self.z_gate = nn.Conv2d(
            self.d_inner, self.d_inner,
            kernel_size=3, padding=1,
            groups=self.d_inner, bias=True,
        )

        self.x_proj = nn.Conv1d(self.d_inner, d_state * 2 + 1, 1, bias=False)

        self.A_log_h = nn.Parameter(torch.log(torch.arange(1, d_state + 1, dtype=torch.float32)))
        self.A_log_w = nn.Parameter(torch.log(torch.arange(1, d_state + 1, dtype=torch.float32)))
        self.D_h = nn.Parameter(torch.ones(self.d_inner))
        self.D_w = nn.Parameter(torch.ones(self.d_inner))

        self.axis_fuse = nn.Conv2d(self.d_inner * 2, self.d_inner, 1, bias=False)

        mid = max(self.d_inner // 16, 4)
        self.energy_gate = nn.Sequential(
            nn.Conv2d(self.d_inner * 2, mid, 1, bias=False),
            nn.GELU(),
            nn.Conv2d(mid, self.d_inner, 1, bias=False),
            nn.Sigmoid(),
        )

        self.out_proj = nn.Conv2d(self.d_inner, dim, 1, bias=False)
        self.out_norm = nn.BatchNorm2d(dim)
        self.dropout = nn.Dropout(dropout) if dropout > 0.0 else nn.Identity()

    def _axis_scan(self, seq, A_log, D_param):
        """seq: [Bsz, Din, L] -> [Bsz, Din, L]"""
        proj = self.x_proj(seq).permute(0, 2, 1)               # [Bsz, L, 2N+1]
        dt = F.softplus(proj[..., :1]).expand(-1, -1, self.d_inner).contiguous()
        B_ssm = proj[..., 1:1 + self.d_state].contiguous()
        C_ssm = proj[..., 1 + self.d_state:].contiguous()

        u = seq.permute(0, 2, 1).contiguous()                  # [Bsz, L, Din]
        A = -A_log.exp()                                       # [N]

        y_fwd = recurrent_selective_scan(u, dt, B_ssm, C_ssm, A, D_param)

        y_bwd = recurrent_selective_scan(
            torch.flip(u, [1]).contiguous(),
            torch.flip(dt, [1]).contiguous(),
            torch.flip(B_ssm, [1]).contiguous(),
            torch.flip(C_ssm, [1]).contiguous(),
            A, D_param,
        )
        y_bwd = torch.flip(y_bwd, [1])

        return (y_fwd + y_bwd).permute(0, 2, 1)                # [Bsz, Din, L]

    def forward(self, x):
        identity = x
        Bsz, _, H, W = x.shape

        x_in = self.act(self.dw_conv(self.in_proj(x).contiguous()))

        seq_h = x_in.permute(0, 3, 1, 2).reshape(Bsz * W, self.d_inner, H)
        y_h = self._axis_scan(seq_h, self.A_log_h, self.D_h)
        y_h = y_h.reshape(Bsz, W, self.d_inner, H).permute(0, 2, 3, 1)

        seq_w = x_in.permute(0, 2, 1, 3).reshape(Bsz * H, self.d_inner, W)
        y_w = self._axis_scan(seq_w, self.A_log_w, self.D_w)
        y_w = y_w.reshape(Bsz, H, self.d_inner, W).permute(0, 2, 1, 3)

        y = self.axis_fuse(torch.cat([y_h, y_w], dim=1))

        avg = F.adaptive_avg_pool2d(y, 1)
        mx = F.adaptive_max_pool2d(y, 1)
        y = y * self.energy_gate(torch.cat([avg, mx], dim=1))

        y = y * self.act(self.z_gate(x_in))

        y = self.dropout(self.out_norm(self.out_proj(y)))
        return identity + y